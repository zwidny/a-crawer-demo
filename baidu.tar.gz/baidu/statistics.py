# -*- coding: utf-8 -*-
from __future__ import absolute_import

import dryscrape

url = 'http://tongji.baidu.com'
dryscrape.start_xvfb()
sess = dryscrape.Session(base_url=url)

sess.visit('/')

sess.render('tongji.baidu.com.png')
login_btn = sess.at_xpath('/html/body/div[2]/div/div[1]/div/span/a[1]/span')
